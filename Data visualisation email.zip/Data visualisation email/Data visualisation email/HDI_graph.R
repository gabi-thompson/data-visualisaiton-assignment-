install.packages("readxl")
install.packages("dplyr")    
install.packages("tidyr")
install.packages("ggplot2")
install.packages("reshape2")
install.packages("showtext")
install.packages("extrafont")
install.packages("tidyverse")
install.packages("sf")
install.packages("viridis")
install.packages("ggspatial")

library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)
library(showtext)
library(extrafont) 
library(tidyverse)
library(sf)
library(viridis)
library(ggspatial)


data <- read_excel("C:/Users/gthomps4/Downloads/Data visualisation email/Data visualisation email/HDI_data.xlsx")

data <- data %>%
  rename(
    HDI_Rank = `...1`, 
    Country = `Table 2. Human Development Index trends, 1990-2022`,
    HDI_1990 = `...3`,
    HDI_2000 = `...5`,
    HDI_2010 = `...7`,
    HDI_2015 = `...9`,
    HDI_2019 = `...11`,
    HDI_2020 = `...13`,
    HDI_2021 = `...15`,
    HDI_2022 = `...17`
  )


# Load Google Fonts
font_add_google("Noto Serif")
font_add_google("Red Hat Text", family = "redhat")
font_add_google("Red Hat Text", regular.wt = 500, family = "redhat2")


# Automatically use showtext
showtext_auto()


# Filtering for the relevant countries 
filtered_data <- data %>%
  filter(Country %in% c("Switzerland", "Australia", "United Arab Emirates", 
                        "China", "Iran (Islamic Republic of)", "Cuba", 
                        "India", "Zimbabwe", "Venezuela (Bolivarian Republic of)", 
                        "Rwanda", "Afghanistan", "Yemen")) %>%
  select(HDI_Rank, Country, HDI_1990, HDI_2000, HDI_2010, HDI_2015, HDI_2019, 
         HDI_2020, HDI_2021, HDI_2022) %>%
  mutate(across(starts_with("HDI"), as.numeric))%>%
  pivot_longer(
    cols = c(HDI_1990, HDI_2000, HDI_2010, HDI_2015, HDI_2019, HDI_2020, HDI_2021, HDI_2022),
    names_to = "Year",
    values_to = "HDI"
  ) %>%
  mutate(
    HDI = as.numeric(HDI),  
    Year = as.numeric(gsub("HDI_", "", Year))  # Convert Year to numeric and remove 'HDI_' prefix
  )

# Creating the plot
ggplot(filtered_data, aes(x = Year, y = HDI, color = Country)) +
  geom_line() +
  geom_point() +
  labs(y = "HDI", x = "Year", title = "Human Development Index of 12 Countries (1990 - 2020)", subtitle = "This line graph illustrates the evolving Human Development Index of 12 countries. Countries like \nSwitzerland and Australia saw steady improvement, while countries such as Zimbabwe, Afghanistan \nand Yemen had slower growth or declines, showing clear differences in development progress across regions.") +
  scale_x_continuous(breaks = seq(1990, 2022, by = 10)) +
  scale_color_manual(values = c("#FF9896", "#999999", "#4DAF4A", "#377EB8",  
                                "#1D3557", "#D35C9B", "#6B4226", "#D95F02",  
                                "#E41A1C", "#BCBD22", "#F9A826", "#7570B3"
  )) + 
  theme_minimal() +
  theme(
    plot.title = element_text(family = "Noto Serif", size = 18),  
    plot.subtitle = element_text(family = "Noto Serif", size = 9.5, margin = margin(b = 20)),  
    axis.text.x = element_text(family = "redhat", margin = margin(t = 10)),  
    axis.text.y = element_text(family = "redhat", margin = margin(r = 10)),  
    axis.title.x = element_text(family = "redhat", margin = margin(t = 20)),  
    axis.title.y = element_text(family = "redhat", margin = margin(r = 20)),  
    legend.title = element_text(family = "redhat2"),  
    legend.text = element_text(family = "redhat2"),
    plot.margin = margin(20, 20, 20, 20) 
  )
