install.packages("readxl")
install.packages("dplyr")    
install.packages("tidyr")
install.packages("ggplot2")
install.packages("reshape2")
install.packages("showtext")
install.packages("extrafont")
install.packages("tidyverse")
install.packages("sf")
install.packages("viridis")
install.packages("ggspatial")
install.packages("leaflet")

library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)
library(showtext)
library(extrafont) 
library(tidyverse)
library(sf)
library(viridis)
library(ggspatial)
library(leaflet)


data <- read_excel("//csce.datastore.ed.ac.uk/csce/biology/users/gthomps4/Win7/Desktop/Data visualisation/HDI_data.xlsx")


data <- data %>%
  rename(
    HDI_Rank = `...1`, 
    Country = `Table 2. Human Development Index trends, 1990-2022`,
    HDI_1990 = `...3`,
    HDI_2000 = `...5`,
    HDI_2010 = `...7`,
    HDI_2015 = `...9`,
    HDI_2019 = `...11`,
    HDI_2020 = `...13`,
    HDI_2021 = `...15`,
    HDI_2022 = `...17`
  )

name_corrections <- c(
  "United States" = "United States of America",
  "Korea (Republic of)" = "South Korea",
  "Russian Federation" = "Russia",
  "Viet Nam" = "Vietnam",
  "Czechia" = "Czech Republic",
  "Türkiye" = "Turkey",
  "Iran (Islamic Republic of)" = "Iran",
  "Bolivia (Plurinational State of)" = "Bolivia",
  "Palestine, State of" = "Palestine",
  "Venezuela (Bolivarian Republic of)" = "Venezuela",
  "Tanzania (United Republic of)" = "Tanzania",
  "Cabo Verde" = "Cape Verde",
  "Micronesia (Federated States of)" = "Federated States of Micronesia",
  "Lao People's Democratic Republic" = "Laos",
  "Sao Tome and Principe" = "São Tomé and Príncipe",
  "Eswatini (Kingdom of)" = "eSwatini",
  "Congo" = "Republic of the Congo",
  "Congo (Democratic Republic of the)" = "Democratic Republic of the Congo",
  "Timor-Leste" = "East Timor",
  "Syrian Arab Republic" = "Syria",
  "Côte d'Ivoire" = "Ivory Coast",
  "Gambia" = "The Gambia",
  "Hong Kong, China (SAR)" = "Hong Kong",
  "China" = "People's Republic of China",
  "North Macedonia"= "Republic of Macedonia",
  "Moldova (Republic of)" = "Moldova"
)

# Filtering for the relevant columns
filtered_data <- data %>%
  select(HDI_Rank, Country, HDI_2022) %>%
  filter(
    if_all(everything(), ~ !is.na(.) & . != "..")  
  ) %>%
  slice(-1) %>%
  mutate(
    across(starts_with("HDI"), as.numeric),
    Country = recode(Country, !!!name_corrections)  # name corrections
  ) %>%
  pivot_longer(
    cols = c(HDI_2022),
    names_to = "Year",
    values_to = "HDI"
  ) %>%
  mutate(
    HDI = as.numeric(HDI),  
    Year = as.numeric(gsub("HDI_", "", Year))  
  )


# Filtering for the relevant columns
map_world <- st_read("C:/Users/Default/Desktop/Data visualisation/WB_countries_Admin0_10m/WB_countries_Admin0_10m.shp")%>%
  st_transform(crs = 4326) %>%  
  select(NAME_EN, OBJECTID) %>%  # Select relevant columns
  rename(Country = NAME_EN)  # Rename column


# Joining map and data
map_joined <- left_join(map_world, filtered_data, by = "Country") %>%
  mutate(HDI = ifelse(is.na(HDI), NA, HDI))  # Confirm NA values in HDI column


# Define the color palette for HDI values using colorNumeric
qpal <- colorNumeric("viridis", domain = map_joined$HDI)

# Create the leaflet map with HDI-based color palette
leaflet(data = map_joined) %>%
  addTiles() %>%  # Add default OpenStreetMap tiles
  addPolygons(
    stroke = FALSE, 
    smoothFactor = 0.2, 
    fillOpacity = 0.9,
    color = ~qpal(HDI),  # Apply the color palette based on HDI values
    popup = ~paste("<strong>Country: </strong>", Country, 
                   "<br><strong>HDI: </strong>", round(HDI, 3)),  # Round HDI to 3 decimal places
    label = ~paste("Country:", Country, "HDI:", round(HDI, 3)),
    highlightOptions = highlightOptions(
      weight = 3,
      color = "white",
      bringToFront = TRUE
    )) %>%
  addLegend(
    pal = qpal,  # The color palette to use
    values = map_joined$HDI[!is.na(map_joined$HDI)],  # Exclude NA values from the legend
    title = "Human Development Index (HDI)",  # Title for the legend
    position = "bottomright",  
    opacity = 1  
  ) %>%
  addScaleBar(position = "bottomleft")

