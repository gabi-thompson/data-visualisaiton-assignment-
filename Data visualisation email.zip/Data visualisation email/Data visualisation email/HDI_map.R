install.packages("readxl")
install.packages("dplyr")    
install.packages("tidyr")
install.packages("ggplot2")
install.packages("reshape2")
install.packages("showtext")
install.packages("extrafont")
install.packages("tidyverse")
install.packages("sf")
install.packages("viridis")
install.packages("ggspatial")

library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(reshape2)
library(showtext)
library(extrafont) 
library(tidyverse)
library(sf)
library(viridis)
library(ggspatial)


data <- read_excel("C:/Users/gthomps4/Downloads/Data visualisation email/Data visualisation email/HDI_data.xlsx")


data <- read_excel("HDI_data.xlsx", skip = 4)


data <- data %>%
  rename(
    HDI_Rank = `HDI rank`,
    HDI_1990 = `1990`,
    HDI_2000 = `2000`,
    HDI_2010 = `2010`,
    HDI_2015 = `2015`,
    HDI_2019 = `2019`,
    HDI_2020 = `2020`,
    HDI_2021 = `2021`,
    HDI_2022 = `2022`
  )


# Load Google Fonts
font_add_google("Oswald")
font_add_google("Red Hat Text", family = "redhat")
font_add_google("Red Hat Text", regular.wt = 500, family = "redhat2")


# Automatically use showtext
showtext_auto()


name_corrections <- c(
  "United States" = "United States of America",
  "Korea (Republic of)" = "South Korea",
  "Russian Federation" = "Russia",
  "Viet Nam" = "Vietnam",
  "Czechia" = "Czech Republic",
  "Türkiye" = "Turkey",
  "Iran (Islamic Republic of)" = "Iran",
  "Bolivia (Plurinational State of)" = "Bolivia",
  "Palestine, State of" = "Palestine",
  "Venezuela (Bolivarian Republic of)" = "Venezuela",
  "Tanzania (United Republic of)" = "Tanzania",
  "Cabo Verde" = "Cape Verde",
  "Micronesia (Federated States of)" = "Federated States of Micronesia",
  "Lao People's Democratic Republic" = "Laos",
  "Sao Tome and Principe" = "São Tomé and Príncipe",
  "Eswatini (Kingdom of)" = "eSwatini",
  "Congo" = "Republic of the Congo",
  "Congo (Democratic Republic of the)" = "Democratic Republic of the Congo",
  "Timor-Leste" = "East Timor",
  "Syrian Arab Republic" = "Syria",
  "Côte d'Ivoire" = "Ivory Coast",
  "Gambia" = "The Gambia",
  "Hong Kong, China (SAR)" = "Hong Kong",
  "China" = "People's Republic of China",
  "North Macedonia"= "Republic of Macedonia",
  "Moldova (Republic of)" = "Moldova"
)

# Filtering for the relevant columns
filtered_data <- data %>%
  select(HDI_Rank, Country, HDI_2022) %>%
  filter(
    if_all(everything(), ~ !is.na(.) & . != "..")  
  ) %>%
  slice(-1) %>%
  mutate(
    across(starts_with("HDI"), as.numeric),
    Country = recode(Country, !!!name_corrections)  # name corrections
  ) %>%
  pivot_longer(
    cols = c(HDI_2022),
    names_to = "Year",
    values_to = "HDI"
  ) %>%
  mutate(
    HDI = as.numeric(HDI),  
    Year = as.numeric(gsub("HDI_", "", Year))  
  )

# Filtering for the relevant columns
map_world <- st_read("C:/Users/gthomps4/Downloads/Data visualisation email/Data visualisation email/WB_countries_Admin0_10m/WB_countries_Admin0_10m.shp") %>%
  st_transform(crs = 4326) %>%  
  select(NAME_EN, OBJECTID) %>%  # Select relevant columns
  rename(Country = NAME_EN)  # Rename column

  
# Joining columns
map_joined <- left_join(map_world, filtered_data, by = "Country") %>%
  mutate(HDI = ifelse(is.na(HDI), NA, HDI))  # Confirm NA values in HDI column

# Plot the map with HDI values
ggplot() + 
  geom_sf(data = map_joined, aes(fill = HDI, color = "")) + 
  scale_fill_gradientn(
    colors = c("#FDE725", "#21908C", "#3B9A6B", "#1F4686"),  # Color palette
    values = scales::rescale(c(0.3, 0.5, 0.7, 0.9)),  # Map colors to the range from 0.3 to 0.9
    na.value = "grey",  # Missing data will be grey
    guide = guide_colorbar(
      title = "HDI 2022", 
      title.position = "top", 
      label.position = "right", 
      labels = c("0.3", "0.5", "0.7", "0.9")  
    )
  ) + 
  labs(
    title = "GLOBAL HUMAN DEVELOPMENT INDEX 2022", 
    subtitle = "A comparative view of Human Development index (HDI) across continents. Regions such as North America, Europe and Oceania exhibit higher HDI \nlevels, while Africa, Asia and South America predominantly reflect medium to lower HDI scores."
  ) + 
  theme_bw() + 
  theme(
    plot.title = element_text(family = "Oswald", size = 18),  
    plot.subtitle = element_text(family = "redhat", size = 9.5),
    axis.text.x = element_text(family = "redhat"),
    legend.title = element_text(family = "redhat"),  
    legend.text = element_text(family = "redhat"),
    plot.margin = margin(20, 20, 20, 20)
  ) + 
  guides(fill = guide_colorbar(
    title = "HDI 2022",
    label.position = "right",
    frame.colour = "black",
    barwidth = 1.5,
    barheight = 10
  ),
colour=guide_legend("Missing HDIs", override.aes=list(colour="grey",
                                                      fill = "grey"))
) + 
  scale_colour_manual(values=NA) + 
  # Add scale bar
  annotation_scale(
    location = "bl", 
    bar_cols = c("grey60", "white")
  ) + 
  # Add north arrow
  annotation_north_arrow(
    location = "bl", 
    pad_x = unit(0.2, "in"), pad_y = unit(0.2, "in"),
    style = north_arrow_nautical(
      fill = c("grey40", "white"),
      line_col = "grey20"
    )
  )
